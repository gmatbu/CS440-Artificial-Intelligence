# Orientation.py

RIGHT = 0
UP = 1
LEFT = 2
DOWN = 3

