// wumpsim.h

#ifndef WUMPSIM_H
#define WUMPSIM_H

#define WUMPSIM_VERSION "3.1"
#define MAX_MOVES_PER_GAME 1000

#endif
